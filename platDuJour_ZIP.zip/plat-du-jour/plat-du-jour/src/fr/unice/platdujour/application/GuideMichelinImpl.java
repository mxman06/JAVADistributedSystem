package fr.unice.platdujour.application;

import java.awt.List;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;

import fr.unice.platdujour.chord.Key;
import fr.unice.platdujour.chord.Peer;
import fr.unice.platdujour.chord.Tracker;

/**
 * This implementation of the {@link GuideMichelin} stores its entries in a 
 * distributed manner. It uses the Chord peer-to-peer network to distribute 
 * storage and to retrieve content.  
 */
public class GuideMichelinImpl implements GuideMichelin {
	
	/** Tracker used to locate the peers that store the entries */
    private final Tracker tracker;
    
    private final int nbReplicate;
     
    private final int nbPeers;
    
    public GuideMichelinImpl(Tracker tracker, int nb, int nbP) {
        this.tracker = tracker;
        this.nbReplicate = nb;
        this.nbPeers = nbP;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean put(String restaurant, String dailySpecial) 
    		throws RemoteException {
    	
    	//r�cup�rer la liste des peers dans lesquelles le restaurant va etre enregistr�
    	ArrayList<Peer> peers = this.findPeers(restaurant);    	
    	
    	// Enregistrer le couple (restaurant, daily special) dans les Peers responsables +  les 2suivants
    	for (Peer p : this.findPeers(restaurant) ){
    		p.put(restaurant, dailySpecial);
    		//p.setReplicatePeers(restaurant, peers);
    	} 
    	return true;
    }

   
    public String get(String restaurant) throws RemoteException, NullPointerException {
    
    	return this.findCloserIndexer(restaurant, nbPeers, (int)Math.random()).get(restaurant);
    }

    /**
     * Locates the nbReplicates peers that must store a content whose key is the restaurant 
     * name.
     * @param restaurant
     * @return The arrayist of peer that are responsible for this key
     * @throws RemoteException
     */
    private final ArrayList<Peer> findPeers(String restaurant) throws RemoteException {
        
    	//create the return List of peers
    	ArrayList<Peer> ret = new ArrayList<Peer>();
    	
    	//initalize the initial Peer where the restaurant should be stored
    	Peer initial= findIndexer(restaurant);
    	
    	//add the initial peer to the return list of peers
    	ret.add(initial);
    	
    	//for 2 next successor
    	for(int i=1; i<this.nbReplicate; i++){
    		
    		initial = initial.getSuccessor();
    		//add the successor to the return list of peers
    		ret.add(initial);
    	}
    	//return th list of peers
    	return ret;
    }
    
    /**
     * Locates the peer that must store a content whose key is the restaurant 
     * name.
     * @param restaurant
     * @return The peer that is responsible for this key
     * @throws RemoteException
     */
    private final Peer findIndexer(String restaurant) throws RemoteException {
        return this.tracker.getRandomPeer().findSuccessor(new Key(restaurant));    
    }
    
    public  Peer findCloserIndexer(String restaurant, int nbPeer, int peerDepart) throws RemoteException {
        return this.tracker.getPeer(peerDepart).findCloserSuccessor(new Key(restaurant), nbPeer);    
    }
    
    
    public void test() throws RemoteException{
    	this.findIndexer("Le Clos Saint-Pierre").die();
    }
    

}
