package fr.unice.platdujour.tests;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.util.Map;
import java.util.Map.Entry;

import fr.unice.platdujour.application.DataGenerator;
import fr.unice.platdujour.application.GuideMichelin;
import fr.unice.platdujour.application.GuideMichelinImpl;
import fr.unice.platdujour.chord.Identifier;
import fr.unice.platdujour.chord.Key;
import fr.unice.platdujour.chord.Peer;
import fr.unice.platdujour.chord.PeerImpl;
import fr.unice.platdujour.chord.Tracker;
import fr.unice.platdujour.chord.TrackerImpl;
import fr.unice.platdujour.exceptions.AlreadyRegisteredException;

public class ReplicateInCache {
	
	/** Number of peers that will be injected in the network */
	private static final int NB_PEERS = 8;
	
	/** Port number of RMI registry */
	private static final int RMI_REGISTRY_PORT = 1099;
	
	/** scale which all peers will have */
	private static final int TRANCHE_IDENTIFIER = 100;
	
	private static final int NB_REPLICATE_PEERS = 3;

	/**
	 * @param args Not used
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {

		// A tracker is created
		new TrackerImpl(RMI_REGISTRY_PORT);

		Tracker tracker =
				(Tracker) Naming.lookup("rmi://localhost:" + RMI_REGISTRY_PORT
						+ "/tracker");
		
		// A Chord network is initialized
		createNetwork(tracker);

		// All the peers in the network are listed
		Thread.sleep((long) (Math.log(NB_PEERS)*1000));
		System.out.println("\nTurn around after first stabilization");
		turnAround(tracker.getRandomPeer());

		Thread.sleep((long) (Math.log(NB_PEERS)*1000));
		System.out.println("\nTurn around after second stabilization");
		turnAround(tracker.getRandomPeer());

		// A GuideMichelin is created. It will use the Chord network
		GuideMichelin guideMichelin = new GuideMichelinImpl(tracker, NB_REPLICATE_PEERS, NB_PEERS);

		// Some data are added to the {@link GuideMichelin}
		DataGenerator dataGenerator = new DataGenerator(2);
		Map<String, String> newData;

		for (int i = 0 ; i < NB_PEERS ; i++) {
			newData = dataGenerator.getNewData();      
			for (Entry<String, String> entry : newData.entrySet()) {
				guideMichelin.put(entry.getKey(), entry.getValue());
			}
		}
		
		// The peers are listed again with the data they store
		Thread.sleep(2000);
		System.out.println("\nTurn around after adding data");
		turnAround(tracker.getRandomPeer());
		
		//System.out.println("test avec 0"+ tracker.getPeer(0).getId() + " " + tracker.getPeer(0).getId()+ " " + tracker.getPeer(0).getId()+ " " + tracker.getPeer(0).getId());
		
		Identifier id = new Key("Clovis");
	
		System.out.println("\n\n\nTest avec restaurant Clovis (indexer=700)\n \n"
				+ "-----en partant de l'ID 300");
		System.out.println("\t le restaurant \"Clovis\" a comme specialite :"
				+guideMichelin.get("Clovis")+
				"\n \tet le peer le plus proche le contenant est celui avec l'ID :"+
				guideMichelin.findCloserIndexer("Clovis", NB_PEERS, 300).getId().getValue()
		);
		
		System.out.println("\n \n------en partant de l'ID 700");
		System.out.println("\t le restaurant \"Clovis\" a comme specialite :"
				+guideMichelin.get("Clovis")+
				"\n et le peer le plus proche le contenant est celui avec l'ID :"+
				guideMichelin.findCloserIndexer("Clovis", NB_PEERS, 700).getId().getValue()
		);
		
		System.out.println("\n \n-----en partant de l'ID 0");
		System.out.println("\t le restaurant \"Clovis\" a comme specialite :"
				+guideMichelin.get("Clovis")+
				"\n et le peer le plus proche le contenant est celui avec l'ID :"+
				guideMichelin.findCloserIndexer("Clovis", NB_PEERS, 0).getId().getValue()				
		);
		
	}
	
	
	
	
	
	
	
	public static void createNetwork(Tracker tracker) 
			throws RemoteException, AlreadyRegisteredException {
		for (int i = 0 ; i < NB_PEERS ; i++) {
			Peer p = new PeerImpl(new Identifier(i * TRANCHE_IDENTIFIER), NB_REPLICATE_PEERS, TRANCHE_IDENTIFIER);

			if (i == 0) {
				System.out.println("Ring created by " + p.getId());
				p.create();
			} 
			else {
				// The new peer is inserted in the network using a random peer 
				// that already belongs to the network. This random peer is 
				// retrieved thanks to the tracker.
				Peer randomPeer = tracker.getRandomPeer();
				System.out.println("Added " + p.getId() + " from "
						+ randomPeer.getId() + " that points to "
						+ randomPeer.getSuccessor().getId());
				p.join(randomPeer);
			}

			tracker.register(p);
		}
	}

	/**
	 * This method run through the entire Chord network and print each 
	 * encountered peer.
	 * @param landmarkPeer The peer from which the turn starts
	 * @throws RemoteException
	 */
	public static void turnAround(Peer landmarkPeer) throws RemoteException {
		System.out.println(
				"\nStarted turn around from " + landmarkPeer.getId());
		Peer nextPeer = landmarkPeer;

		do {
			nextPeer = nextPeer.getSuccessor();
			
			System.out.println("Visited " + nextPeer.describe());

		} while (!nextPeer.equals(landmarkPeer));
	}
}
