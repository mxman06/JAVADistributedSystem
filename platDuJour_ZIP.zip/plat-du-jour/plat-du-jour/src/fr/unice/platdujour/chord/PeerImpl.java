package fr.unice.platdujour.chord;

import java.rmi.NoSuchObjectException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Implementation of the {@link Peer} API.
 */
public class PeerImpl extends UnicastRemoteObject implements Comparable<Peer>,
Peer {

	/** Default serialization ID */
	private static final long serialVersionUID = 1L;

	/** Identifier of the peer in the virtual ring */
	private final Identifier id;

	/** Local storage for entries that have an identifier that is managed by  
	 * the peer */
	private final Map<String, String> directory;

	public Map<String, String> getDirectory() {
		return directory;
	}

	/** Peer that is just before in the virtual ring */
	private Peer predecessor;

	/** Peer that is just after in the virtual ring */
	private Peer successor;
	
	private int nbReplicate;
	
	private int scaleId;

	/** Successor peer of the successor for new links when a peer die*/
	private Peer successorOfSuccessor;
	
	ScheduledExecutorService threadPool;
	
	public PeerImpl(Identifier id, int nbReplicates, int scale) throws RemoteException {
		this.id = id;
		this.predecessor = this;
		this.successor = this;
		this.directory = new HashMap<String, String>();
		this.nbReplicate = nbReplicates;
		this.successorOfSuccessor = this;
		this.scaleId = scale;
		
		threadPool =Executors.newScheduledThreadPool(1);
		threadPool.scheduleAtFixedRate(new Runnable() {
			@Override
			public void run() {
				try {
					
					PeerImpl.this.stabilize();
					
				} catch (RemoteException e) {
					// TODO: handle exception
					e.printStackTrace();
				} 
			}
		}, 0, 500, TimeUnit.MILLISECONDS);
		
	}
	
	public void stopStabilize(){
		threadPool.shutdown();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public synchronized void create() throws RemoteException {
		this.predecessor = null;
		// The bootstrap of the Chord network requires a self loop
		this.successor = this;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public synchronized void join(Peer landmarkPeer) throws RemoteException {
		this.predecessor = null;
		// To join the network, ask a peer that is already in the network to 
		// find which peer must be the successor of the joining peer, using 
		// the identifier of the joining peer
		this.successor = landmarkPeer.findSuccessor(this.id);
		// The stabilize method will then update all the other links correctly
		
		this.successorOfSuccessor = this.successor.getSuccessor();
		
	}

	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public Peer findCloserSuccessor(Identifier id, int nbPeer) throws RemoteException {
		// There is only one peer in the network
		if (this.successor.equals(this)) {
			return this;
		}
		Identifier idPlusScale;	
		
		// boucler sur les nbReplicate ou lid a �t� enregistr�
		for(int i=0; i<this.nbReplicate; i++){
							
			idPlusScale = new Identifier( id.getValue() + (i*scaleId));
			
			//on test si la ressource passe du dernier au premier peer (id > id dernier peer)
			if( idPlusScale.getValue() > ((nbPeer*scaleId)-scaleId)){
				//System.out.println(idPlusScale.getValue() + "  " + ((nbPeer*scaleId)-scaleId) + "  " + this.getId().getValue());
				//idPlusScale = new Identifier(0);
				
				for(int j=0; j<i; j++){
					idPlusScale = new Identifier(0+(j*scaleId));	
				}
				
			}
			
			//on test si l'id du peer courant est dans l'interval denregistrement de l'id
			//(id + scale) pour continuer		
			if ( idPlusScale.isBetweenOpenClosed(this.getId(), this.successor.getId()) ){
				return this.successor;
			}
		}		
		return this.successor.findCloserSuccessor(id, nbPeer); 
	}
	
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public Peer findSuccessor(Identifier id) throws RemoteException {
		// There is only one peer in the network
		if (this.successor.equals(this)) {
			return this;
		}
		// The specified identifier is in between the current peer identifier 
		// and the successor identifier: the successor is then the peer we are 
		// looking for
		if (id.isBetweenOpenClosed(this.id, this.successor.getId())) {
			return this.successor;
		}
		// Nothing can be deduced from the specified identifier here: 
		// propagate the request in case the successor knows more about it
		else {
			return this.successor.findSuccessor(id);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Identifier getId() throws RemoteException {
		return this.id;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Peer getPredecessor() throws RemoteException {
		return this.predecessor;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Peer getSuccessor() throws RemoteException {
		return this.successor;
	}

	public int getNbReplicate() {
		return this.nbReplicate;
	}

	

	public int getScaleId() {
		return scaleId;
	}

	public void setScaleId(int scaleId) {
		this.scaleId = scaleId;
	}
	/**
	 * {@inheritDoc}
	 */
	@Override
	public synchronized void setPredecessor(Peer peer) throws RemoteException {
		this.predecessor = peer;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public synchronized void setSuccessor(Peer peer) throws RemoteException {
		this.successor = peer;
	}


	public Peer getSuccessorOfSuccessor() throws RemoteException{
		return successorOfSuccessor;
	}

	public void setSuccessorOfSuccessor(Peer successorOfSuccessor) throws RemoteException {
		this.successorOfSuccessor = successorOfSuccessor;
	}
	
	public void setNbReplicate(int nbReplicate) {
		this.nbReplicate = nbReplicate;
	}
	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean equals(Object obj) {
		try {
			// Two peers are equal if they have the same identifier
			return this.id.equals(((Peer) obj).getId());
		} catch (RemoteException e) {
			return false;
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode() {
		// The hashcode of a peer is the hashcode of its identifier
		return this.id.hashCode();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int compareTo(Peer p) {
		try {
			return this.id.compareTo(p.getId());
		} catch (RemoteException e) {
			e.printStackTrace();
			return -1;
		}
	}


	/**
	 * {@inheritDoc}
	 * @throws InterruptedException 
	 */
	@Override
	public synchronized void stabilize() throws NoSuchObjectException, RemoteException {		
		
		// x should be this itself, but it is not always the case, typically 
		// if the successor has recently taken a new peer as predecessor
		Peer x = null;
		try{
			x = this.successor.getPredecessor();
			// If x is this itself, then this condition is not valid. This 
			// condition is valid if the successor has another peer as predecessor,
			// then in this case we check if this other peer is indeed included in 
			// the current identifier and the identifier of the successor. If it 
			// is, then it mean that x must be the new successor.
		

			if (x != null && x.getId().isBetweenOpenClosed(this.id, this.successor.getId()) ) {
				this.successor = x;
			}
				// The current peer needs to inform its successor that it is indeed its
				// successor 
				this.successor.notify(PeerImpl.this);
				
				// initalize the successor of the successor
				this.successorOfSuccessor = this.successor.getSuccessor();
			}
		catch(NoSuchObjectException e){
			//
			////////////////////MAJ des pointeurs/////////////////////////
			
			this.successor = this.getSuccessorOfSuccessor();		
		 	
			//mise a jour du pointeur de celui apres le peer mort
		 	this.successor.setPredecessor(this);		 				 	 		 
 		   			   	
 		   	//mise a jour du succofsucc
		 	this.setSuccessorOfSuccessor(this.getSuccessorOfSuccessor().getSuccessor());
		 	
		 	
		 	
		 	///////////////////////Contabilisation des donn�es////////////////
		 	Peer nextPeer = this;
		 	HashMap<String, String> datas = new HashMap<String, String>();
		 	HashMap<String, String> dataByPeer = new HashMap<String, String>();
		 	HashMap<String, Integer> nbReplicateByDaily = new HashMap<String, Integer>();
		 	
		 	//recup�ration de toutes les donn�es		 			 	
		 	do{		 		
		 		//on recupere les donn�es du pper
		 		dataByPeer = (HashMap<String, String>) nextPeer.getDirectory();
		 		//on recup�re les clefs
		 		for(String resto : dataByPeer.keySet()){
		 			//si on les a deja comtabilis� on incr�mente le nb de replicate 
		 			if(nbReplicateByDaily.containsKey(resto+"/"+dataByPeer.get(resto))){
		 				int nb = nbReplicateByDaily.get(resto+"/"+dataByPeer.get(resto));
		 				nbReplicateByDaily.put(resto+"/"+dataByPeer.get(resto), nb+1);
		 			}
		 			else{
		 				nbReplicateByDaily.put(resto+"/"+dataByPeer.get(resto), 1);
		 			}		 					 			
		 		}
		 		nextPeer = nextPeer.getSuccessor();		 		
		 	}
		 	
		 	while( !this.equals(nextPeer));
		 	
		 	////////////////////////////r�injecter les donn�es dont//////////////
		 	///////////////////////////le nbreplicate est plus petit////////////
		 	///////////////////////////que this.nbReplicate////////////////////
		 	String resto, daily;
		 	String[] stringToSplit;
		 	for(String dataToRestore : nbReplicateByDaily.keySet()){
		 		if(nbReplicateByDaily.get(dataToRestore) < this.nbReplicate){
		 			stringToSplit = dataToRestore.split("/");
		 			resto = stringToSplit[0];
		 			daily = stringToSplit[1];
		 			
		 			Peer peerIntoResave = findSuccessor(new Key(resto));
		 			for(int i=1; i<nbReplicate; i++){
		 				peerIntoResave = peerIntoResave.getSuccessor();
		 			}
		 			peerIntoResave.put(resto, daily);
		 		}
		 	}
		 	
		}
		
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public synchronized void notify(Peer peer) throws RemoteException {
		// If a new peer notify itself as a predecessor of the current peer, 
		// check if it fits in the interval of the previous predecessor 
		// identifier and it own identifier. If yes, take it as predecessor.
		// Otherwise, nothing needs to be done.
		if (this.predecessor == null
				|| peer.getId().isBetweenOpenOpen(
						this.predecessor.getId(), this.id)) {
			this.predecessor = peer;
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public synchronized void put(String restaurant, String dailySpecial)
			throws RemoteException {
		this.directory.put(restaurant, dailySpecial);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String get(String restaurant) throws RemoteException {		
		return this.directory.get(restaurant);
		
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String describe() throws RemoteException {
		StringBuilder s = new StringBuilder("Peer [id=" + this.id + 
				", successor=" + this.successor.getId() + ", predecessor="
				+ this.predecessor.getId() + ", successor of successor=" + this.successorOfSuccessor.getId() + ", values=[");

		int cpt = 0;
		int size = this.directory.size();
		for (Entry<String,String> entry : this.directory.entrySet()) {
			s.append("(" + entry.getKey() + ";" + entry.getValue() + ")");
			if (++cpt != size) {
				s.append(", ");
			}
		}

		s.append(" ]");
		return s.toString();
	}

	/**
	 * {@inheritDoc}
	 */
	public void die() throws RemoteException {

		
		// Removes this from the RMI runtime. It will prevent all RMI calls 
		// from executing on this object. A further RMI call on this will 
		// cause a java.rmi.NoSuchObjectException.
		UnicastRemoteObject.unexportObject(this, true);		
		
		this.stopStabilize();
		System.out.println("Peer with id " + this.id + " has died.");
	}

	
	public boolean alive() throws RemoteException {
		// TODO Auto-generated method stub
		return true;
	}

}
